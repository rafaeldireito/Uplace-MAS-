$( document ).ready(function copytable() {
	  var source = localStorage.tabela;
	  var destination = document.getElementById('tabelaFav');

destination.document.write(source.innerHTML);


	});
