$( document ).ready(function() {
document.getElementById(conta).innerHTML=user
});
